# POSTAPP Billing Engine V26 FULL PRO

This package contains a production-oriented billing layer for POSTAPP.

## Included
- Stripe subscription checkout
- One-time submission checkout
- Entitlements middleware
- Submission credit tracking scaffold
- Billing status endpoint
- Frontend pricing hooks
- Submission checkout modal
- Integration examples for Express

## Environment variables

Create a `.env` file with:

```bash
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
STRIPE_PRICE_SOLO=
STRIPE_PRICE_BUILDER=
STRIPE_PRICE_STUDIO=
STRIPE_PRICE_SUBMISSION_STANDARD=
STRIPE_PRICE_SUBMISSION_COMPLEX=
APP_BASE_URL=
```

## Suggested integration
Mount these in your main Express app:
- `/api/billing`
- `/api/submissions`

You will also need:
- an auth middleware that sets `req.user`
- a real database layer for users, subscriptions, purchases, and submission credits

## Notes
- Stripe webhooks require a raw request body on the webhook route.
- The included route code uses a simple placeholder DB pattern and comments where production DB logic should go.
- Replace all placeholder DB logic with your own persistent storage before going live.
