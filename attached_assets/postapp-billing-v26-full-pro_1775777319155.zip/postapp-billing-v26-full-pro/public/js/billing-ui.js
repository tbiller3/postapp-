async function createPlanCheckout(planName) {
  const res = await fetch("/api/billing/create-checkout-session", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ planName })
  });

  const data = await res.json();

  if (!res.ok) {
    alert(data.error || "Could not start checkout.");
    return;
  }

  window.location.href = data.url;
}

async function createSubmissionCheckout(projectId, submissionType = "standard") {
  const res = await fetch("/api/billing/create-submission-session", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ projectId, submissionType })
  });

  const data = await res.json();

  if (!res.ok) {
    alert(data.error || "Could not start submission checkout.");
    return;
  }

  window.location.href = data.url;
}

function bindPricingButtons() {
  document.querySelectorAll("[data-plan-button]").forEach((btn) => {
    btn.addEventListener("click", () => {
      createPlanCheckout(btn.dataset.planButton);
    });
  });
}

function openSubmissionCheckoutModal({
  projectId,
  projectName,
  submissionType = "standard"
}) {
  const modal = document.getElementById("submissionCheckoutModal");
  const nameEl = document.getElementById("submissionProjectName");
  const typeEl = document.getElementById("submissionTypeLabel");
  const priceEl = document.getElementById("submissionPriceLabel");
  const confirmBtn = document.getElementById("confirmSubmissionCheckout");
  const cancelBtn = document.getElementById("cancelSubmissionCheckout");

  nameEl.textContent = `Project: ${projectName}`;
  typeEl.textContent = submissionType === "complex" ? "Complex App" : "Standard App";
  priceEl.textContent = submissionType === "complex" ? "$349+" : "$199";

  modal.classList.remove("hidden");

  const confirmHandler = async () => {
    confirmBtn.removeEventListener("click", confirmHandler);
    cancelBtn.removeEventListener("click", cancelHandler);
    modal.classList.add("hidden");
    await createSubmissionCheckout(projectId, submissionType);
  };

  const cancelHandler = () => {
    confirmBtn.removeEventListener("click", confirmHandler);
    cancelBtn.removeEventListener("click", cancelHandler);
    modal.classList.add("hidden");
  };

  confirmBtn.addEventListener("click", confirmHandler);
  cancelBtn.addEventListener("click", cancelHandler);
}

async function checkBillingStatus() {
  const res = await fetch("/api/billing/status");
  const data = await res.json();
  return data;
}

document.addEventListener("DOMContentLoaded", () => {
  bindPricingButtons();
});
