const express = require("express");
const {
  createSubscriptionCheckoutSession,
  createSubmissionCheckoutSession,
  constructWebhookEvent
} = require("../services/billingService");

const router = express.Router();

router.get("/status", async (req, res) => {
  const user = req.user;

  return res.json({
    ok: true,
    plan: user.plan_name || "free",
    stripe_customer_id: user.stripe_customer_id || null,
    subscription_status: user.subscription_status || "inactive"
  });
});

router.post("/create-checkout-session", async (req, res, next) => {
  try {
    const { planName } = req.body;
    const session = await createSubscriptionCheckoutSession({
      user: req.user,
      planName
    });

    res.json({ ok: true, url: session.url });
  } catch (err) {
    next(err);
  }
});

router.post("/create-submission-session", async (req, res, next) => {
  try {
    const { projectId, submissionType } = req.body;

    const session = await createSubmissionCheckoutSession({
      user: req.user,
      projectId,
      submissionType
    });

    res.json({ ok: true, url: session.url });
  } catch (err) {
    next(err);
  }
});

router.post("/webhook", async (req, res, next) => {
  try {
    const signature = req.headers["stripe-signature"];
    const event = await constructWebhookEvent(req.body, signature);

    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object;
        const metadata = session.metadata || {};

        // TODO: replace these placeholders with your DB layer.
        // Handle subscription purchase:
        // - set user.plan_name
        // - set user.subscription_status
        // - store stripe_customer_id / stripe_subscription_id

        // Handle one-time submission purchase:
        // - create submission credit record tied to user + project

        console.log("Webhook completed:", metadata);
        break;
      }

      case "customer.subscription.deleted":
      case "customer.subscription.updated": {
        const subscription = event.data.object;
        console.log("Subscription updated:", subscription.id);
        break;
      }

      default:
        console.log("Unhandled Stripe event:", event.type);
    }

    res.json({ received: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
