const express = require("express");
const billingRoutes = require("./routes/billing");
const submissionRoutes = require("./routes/submissions");

const app = express();
const PORT = process.env.PORT || 3000;

app.locals.mockDb = {
  submission_credits: []
};

// NOTE:
// In production, do not mount the same billing router twice.
// Split webhook handling into a dedicated raw-body route if needed.

app.use(express.json());

app.use((req, res, next) => {
  req.user = {
    id: "user_123",
    email: "demo@postapp.com",
    name: "Demo User",
    plan_name: "free",
    subscription_status: "inactive",
    stripe_customer_id: null
  };
  next();
});

app.use("/api/billing", billingRoutes);
app.use("/api/submissions", submissionRoutes);

app.listen(PORT, () => {
  console.log(`POSTAPP Billing Engine running on http://localhost:${PORT}`);
});
