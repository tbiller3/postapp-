# POSTAPP V25 — Actionable Checklist System

This is a standalone integration pack for the **Full V25 System** requested for POSTAPP.
It is designed to drop into a React/Vite-style app and demonstrates:

- action-aware checklist rows
- per-item status (`complete`, `warning`, `missing`, `auto`)
- internal navigation actions
- external guideline links
- inline explanations
- a global **Fix Critical Issues** panel
- grouped checklist sections
- optional quick filters

## What this pack includes

- `src/App.tsx` — demo page
- `src/data/checklist.ts` — checklist definitions
- `src/components/ActionableChecklist.tsx`
- `src/components/ChecklistItemCard.tsx`
- `src/components/FixPanel.tsx`
- `src/utils/checklistActions.ts`
- `src/styles.css`

## Integration notes

1. Copy the `src/` files into your current POSTAPP project.
2. Replace the mock `navigateTo()` function in `src/utils/checklistActions.ts` with your router logic.
3. Replace `window.open()` external links with your preferred link handler if needed.
4. Wire the `onToggleComplete` callback to your own project persistence layer.
5. Feed real project data into `buildSections()` to produce live statuses.

## Suggested next integration step

Map your existing checklist items to these action types:

- `internal` → navigate to Assets / Metadata / Account / Projects / Analyzer
- `external` → Apple docs / App Store Connect / Certificates / Privacy docs
- `modal` → open local help / explanation drawer / remediation sheet

## Status model

- `complete` — verified done
- `auto` — detected automatically by analyzer
- `warning` — needs review
- `missing` — not done / blocker

