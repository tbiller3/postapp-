import React from 'react';
import { ActionableChecklist } from './components/ActionableChecklist';
import { buildSections } from './data/checklist';
import './styles.css';

export default function App() {
  const sections = buildSections();

  return (
    <main className="app-shell">
      <header className="hero">
        <div>
          <p className="eyebrow">POSTAPP V25</p>
          <h1>Full Actionable Checklist System</h1>
          <p className="subtitle">
            Every checklist row now includes status, guidance, and direct action paths so users can retrieve,
            verify, and fix submission requirements without hunting around the app.
          </p>
        </div>
      </header>

      <ActionableChecklist sections={sections} />
    </main>
  );
}
