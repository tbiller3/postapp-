import React, { useMemo, useState } from 'react';
import { ChecklistSection, ChecklistItem } from '../data/checklist';
import { ChecklistItemCard } from './ChecklistItemCard';
import { FixPanel } from './FixPanel';

interface Props {
  sections: ChecklistSection[];
}

export function ActionableChecklist({ sections }: Props) {
  const [itemsState, setItemsState] = useState<Record<string, boolean>>({});
  const [activeFilter, setActiveFilter] = useState<'all' | 'blockers' | 'review'>('all');
  const [modalKey, setModalKey] = useState<string | null>(null);

  const hydratedSections = useMemo(() => {
    return sections.map((section) => ({
      ...section,
      items: section.items.map((item) => ({
        ...item,
        checked: itemsState[item.id] ?? item.checked
      }))
    }));
  }, [sections, itemsState]);

  const allItems = hydratedSections.flatMap((section) => section.items);
  const blockers = allItems.filter((item) => item.blocker && !item.checked);

  const filteredSections = hydratedSections.map((section) => ({
    ...section,
    items: section.items.filter((item) => {
      if (activeFilter === 'blockers') return item.blocker && !item.checked;
      if (activeFilter === 'review') return item.status === 'warning' && !item.checked;
      return true;
    })
  })).filter((section) => section.items.length > 0);

  function onToggleComplete(itemId: string) {
    setItemsState((prev) => ({
      ...prev,
      [itemId]: !prev[itemId]
    }));
  }

  function navigateTo(target: string) {
    alert(`Navigate to: ${target}`);
  }

  function openModal(target: string) {
    setModalKey(target);
  }

  return (
    <div className="actionable-checklist">
      <div className="toolbar">
        <button className={activeFilter === 'all' ? 'toolbar__active' : ''} onClick={() => setActiveFilter('all')}>All</button>
        <button className={activeFilter === 'blockers' ? 'toolbar__active' : ''} onClick={() => setActiveFilter('blockers')}>Critical</button>
        <button className={activeFilter === 'review' ? 'toolbar__active' : ''} onClick={() => setActiveFilter('review')}>Needs Review</button>
      </div>

      <FixPanel blockers={blockers} navigateTo={navigateTo} openModal={openModal} />

      <div className="section-stack">
        {filteredSections.map((section) => (
          <section key={section.id} className="check-section">
            <div className="check-section__header" style={{ borderLeftColor: section.accent }}>
              <h3>{section.title}</h3>
              <span>{section.items.filter((item) => item.checked).length}/{section.items.length}</span>
            </div>

            <div className="check-section__body">
              {section.items.map((item: ChecklistItem) => (
                <ChecklistItemCard
                  key={item.id}
                  item={item}
                  onToggleComplete={onToggleComplete}
                  navigateTo={navigateTo}
                  openModal={openModal}
                />
              ))}
            </div>
          </section>
        ))}
      </div>

      {modalKey && (
        <div className="overlay" onClick={() => setModalKey(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>Guidance</h3>
            <p>This is the contextual help panel for: <strong>{modalKey}</strong>.</p>
            <p>In your live POSTAPP build, this would contain fix instructions, requirement explanations, and retrieval guidance.</p>
            <button onClick={() => setModalKey(null)}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
}
