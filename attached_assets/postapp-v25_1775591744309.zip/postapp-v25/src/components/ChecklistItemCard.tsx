import React from 'react';
import { ChecklistItem } from '../data/checklist';
import { getStatusChipLabel, runChecklistAction } from '../utils/checklistActions';

interface Props {
  item: ChecklistItem;
  onToggleComplete: (itemId: string) => void;
  navigateTo?: (target: string) => void;
  openModal?: (target: string) => void;
}

export function ChecklistItemCard({ item, onToggleComplete, navigateTo, openModal }: Props) {
  return (
    <div className={`check-card check-card--${item.status}`}>
      <div className="check-card__left">
        <input
          type="checkbox"
          checked={item.checked}
          onChange={() => onToggleComplete(item.id)}
          aria-label={`Mark ${item.title} complete`}
        />
      </div>

      <div className="check-card__content">
        <div className="check-card__topline">
          <h4>{item.title}</h4>
          <span className={`status-chip status-chip--${item.status}`}>{getStatusChipLabel(item.status)}</span>
        </div>

        <p className="check-card__description">{item.description}</p>

        {item.helpText && <p className="check-card__help">{item.helpText}</p>}

        <div className="check-card__actions">
          {item.actions.map((action, idx) => (
            <button
              key={`${item.id}-${idx}`}
              className="action-pill"
              onClick={() => runChecklistAction(action, { navigateTo, openModal })}
            >
              {action.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
