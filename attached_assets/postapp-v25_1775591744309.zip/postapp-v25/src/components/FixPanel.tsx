import React from 'react';
import { ChecklistItem } from '../data/checklist';
import { runChecklistAction } from '../utils/checklistActions';

interface Props {
  blockers: ChecklistItem[];
  navigateTo?: (target: string) => void;
  openModal?: (target: string) => void;
}

export function FixPanel({ blockers, navigateTo, openModal }: Props) {
  const topBlockers = blockers.slice(0, 3);

  return (
    <section className="fix-panel">
      <div className="fix-panel__header">
        <h3>Fix Critical Issues</h3>
        <span>{topBlockers.length}</span>
      </div>

      {topBlockers.length === 0 ? (
        <div className="fix-panel__empty">No critical blockers right now.</div>
      ) : (
        <div className="fix-panel__list">
          {topBlockers.map((item) => (
            <div key={item.id} className="fix-panel__item">
              <div>
                <strong>{item.title}</strong>
                <p>{item.description}</p>
              </div>

              <div className="fix-panel__buttons">
                {item.actions.slice(0, 2).map((action, idx) => (
                  <button
                    key={`${item.id}-fix-${idx}`}
                    className="primary-fix"
                    onClick={() => runChecklistAction(action, { navigateTo, openModal })}
                  >
                    {action.label}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
