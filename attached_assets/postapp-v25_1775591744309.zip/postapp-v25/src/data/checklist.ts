export type ChecklistStatus = 'complete' | 'warning' | 'missing' | 'auto';
export type ActionType = 'internal' | 'external' | 'modal';

export interface ChecklistAction {
  type: ActionType;
  label: string;
  target: string;
}

export interface ChecklistItem {
  id: string;
  title: string;
  description: string;
  status: ChecklistStatus;
  checked: boolean;
  blocker: boolean;
  sectionId: string;
  helpText?: string;
  actions: ChecklistAction[];
}

export interface ChecklistSection {
  id: string;
  title: string;
  accent: string;
  items: ChecklistItem[];
}

export function buildSections(): ChecklistSection[] {
  return [
    {
      id: 'assets',
      title: 'Assets & Screenshots',
      accent: '#22c55e',
      items: [
        {
          id: 'icon-1024',
          title: 'App icon meets requirements (1024×1024 PNG, no alpha)',
          description: 'Required for App Store submission. PNG only, no transparency, no rounded corners.',
          status: 'missing',
          checked: false,
          blocker: true,
          sectionId: 'assets',
          helpText: 'Apple expects a 1024×1024 marketing icon with no alpha channel.',
          actions: [
            { type: 'internal', label: 'Go to Assets', target: '/assets' },
            { type: 'modal', label: 'Why this matters', target: 'iconRequirements' },
            { type: 'external', label: 'Apple icon guidance', target: 'https://developer.apple.com/design/human-interface-guidelines/app-icons' }
          ]
        },
        {
          id: 'screenshots-iphone',
          title: 'Screenshots provided for required iPhone sizes',
          description: 'Prepare current required iPhone screenshot set before upload.',
          status: 'warning',
          checked: false,
          blocker: false,
          sectionId: 'assets',
          helpText: 'At minimum, make sure your primary iPhone device family is covered.',
          actions: [
            { type: 'internal', label: 'Open Screenshots', target: '/assets/screenshots' },
            { type: 'modal', label: 'View size guide', target: 'screenshotGuide' }
          ]
        }
      ]
    },
    {
      id: 'metadata',
      title: 'Build Metadata',
      accent: '#8b5cf6',
      items: [
        {
          id: 'version-string',
          title: 'Version string is updated',
          description: 'CFBundleShortVersionString should match the new release version.',
          status: 'complete',
          checked: true,
          blocker: false,
          sectionId: 'metadata',
          helpText: 'Use a new marketing version for each release.',
          actions: [
            { type: 'internal', label: 'Open Metadata', target: '/metadata' },
            { type: 'modal', label: 'Version examples', target: 'versionExamples' }
          ]
        },
        {
          id: 'build-number',
          title: 'Build number is incremented',
          description: 'Each upload must use a unique build number.',
          status: 'warning',
          checked: false,
          blocker: false,
          sectionId: 'metadata',
          helpText: 'If the build number duplicates an earlier upload, App Store Connect rejects it.',
          actions: [
            { type: 'internal', label: 'Edit build number', target: '/metadata/build' },
            { type: 'external', label: 'App Store Connect help', target: 'https://developer.apple.com/help/app-store-connect/manage-builds/upload-builds/' }
          ]
        }
      ]
    },
    {
      id: 'privacy',
      title: 'Privacy & Permissions',
      accent: '#f59e0b',
      items: [
        {
          id: 'privacy-policy',
          title: 'Privacy policy URL is valid and accessible',
          description: 'A reachable privacy policy is expected when your app collects data or uses network services.',
          status: 'missing',
          checked: false,
          blocker: true,
          sectionId: 'privacy',
          helpText: 'Use a live URL that reviewers can open.',
          actions: [
            { type: 'internal', label: 'Edit privacy URL', target: '/metadata/privacy' },
            { type: 'modal', label: 'What to include', target: 'privacyPolicyHelp' }
          ]
        },
        {
          id: 'usage-strings',
          title: 'Required privacy usage strings are present',
          description: 'If your app uses camera, microphone, photos, location, contacts, or Bluetooth, usage descriptions are required.',
          status: 'warning',
          checked: false,
          blocker: true,
          sectionId: 'privacy',
          helpText: 'Missing privacy strings are a very common rejection cause.',
          actions: [
            { type: 'internal', label: 'Open privacy keys', target: '/metadata/privacy-keys' },
            { type: 'external', label: 'Apple privacy docs', target: 'https://developer.apple.com/app-store/user-privacy-and-data-use/' }
          ]
        }
      ]
    },
    {
      id: 'review',
      title: 'Review Preparation',
      accent: '#ec4899',
      items: [
        {
          id: 'review-notes',
          title: 'Review notes explain any special flows',
          description: 'Explain anything that could look unusual or blocked to a reviewer.',
          status: 'warning',
          checked: false,
          blocker: false,
          sectionId: 'review',
          helpText: 'If login, setup, or special flows exist, document them for review.',
          actions: [
            { type: 'internal', label: 'Open review notes', target: '/review/notes' },
            { type: 'modal', label: 'See example notes', target: 'reviewNotesExample' }
          ]
        },
        {
          id: 'test-account',
          title: 'Test account credentials are provided if required',
          description: 'If the app requires login for review, provide working reviewer credentials.',
          status: 'complete',
          checked: true,
          blocker: false,
          sectionId: 'review',
          helpText: 'Guest mode also helps reduce review friction.',
          actions: [
            { type: 'internal', label: 'Open account settings', target: '/account' },
            { type: 'modal', label: 'Reviewer access tips', target: 'reviewerAccess' }
          ]
        }
      ]
    }
  ];
}
