import { ChecklistAction } from '../data/checklist';

export function runChecklistAction(action: ChecklistAction, helpers?: {
  navigateTo?: (target: string) => void;
  openModal?: (target: string) => void;
}) {
  if (action.type === 'internal') {
    if (helpers?.navigateTo) {
      helpers.navigateTo(action.target);
      return;
    }
    console.log('Navigate internally to:', action.target);
    return;
  }

  if (action.type === 'modal') {
    if (helpers?.openModal) {
      helpers.openModal(action.target);
      return;
    }
    console.log('Open helper modal:', action.target);
    return;
  }

  if (action.type === 'external') {
    window.open(action.target, '_blank', 'noopener,noreferrer');
  }
}

export function getStatusChipLabel(status: string) {
  switch (status) {
    case 'complete': return 'Complete';
    case 'auto': return 'Auto';
    case 'warning': return 'Needs Review';
    case 'missing': return 'Missing';
    default: return 'Unknown';
  }
}
