# POSTAPP V27 — App Store Connect Sync Scaffold

This is a production-oriented scaffold for connecting POSTAPP to App Store Connect.

## What it adds
- JWT-based App Store Connect auth on the server
- Server endpoints for:
  - `/api/apple/health`
  - `/api/apple/apps`
  - `/api/apple/apps/:id`
  - `/api/apple/apps/:id/appStoreVersions`
- Frontend client for calling those endpoints
- Zustand store for connection state
- React components for:
  - connect status
  - app selector
  - app summary
  - version list

## Environment variables
Create a `.env` file for the server with:

```bash
APPLE_ISSUER_ID=
APPLE_KEY_ID=
APPLE_PRIVATE_KEY=-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----
PORT=3001
```

You may also use `APPLE_PRIVATE_KEY_BASE64` instead of `APPLE_PRIVATE_KEY`.

## Install
Server:
```bash
cd server
npm install
npm run dev
```

Frontend: merge the `src/` files into your existing React/Vite app.

## Notes
- This scaffold does not submit builds yet.
- It is focused on **live App Store Connect metadata sync**.
- Keep all Apple secrets on the server only.
