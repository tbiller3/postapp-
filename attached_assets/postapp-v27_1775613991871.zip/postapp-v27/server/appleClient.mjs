import jwt from 'jsonwebtoken';

const APPLE_BASE = 'https://api.appstoreconnect.apple.com/v1';

function getPrivateKey() {
  if (process.env.APPLE_PRIVATE_KEY?.trim()) {
    return process.env.APPLE_PRIVATE_KEY.replace(/\\n/g, '\n');
  }
  if (process.env.APPLE_PRIVATE_KEY_BASE64?.trim()) {
    return Buffer.from(process.env.APPLE_PRIVATE_KEY_BASE64, 'base64').toString('utf8');
  }
  throw new Error('Missing Apple private key. Set APPLE_PRIVATE_KEY or APPLE_PRIVATE_KEY_BASE64.');
}

export function createAppleJwt() {
  const issuer = process.env.APPLE_ISSUER_ID;
  const keyId = process.env.APPLE_KEY_ID;
  const privateKey = getPrivateKey();

  if (!issuer || !keyId) {
    throw new Error('Missing APPLE_ISSUER_ID or APPLE_KEY_ID.');
  }

  const now = Math.floor(Date.now() / 1000);
  return jwt.sign(
    {
      iss: issuer,
      aud: 'appstoreconnect-v1',
      exp: now + 60 * 15
    },
    privateKey,
    {
      algorithm: 'ES256',
      header: { alg: 'ES256', kid: keyId, typ: 'JWT' }
    }
  );
}

export async function appleFetch(path, init = {}) {
  const token = createAppleJwt();
  const res = await fetch(`${APPLE_BASE}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      ...(init.headers || {})
    }
  });

  const text = await res.text();
  let json;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    json = { raw: text };
  }

  if (!res.ok) {
    const err = new Error(json?.errors?.[0]?.detail || `Apple API error: ${res.status}`);
    err.status = res.status;
    err.payload = json;
    throw err;
  }

  return json;
}
