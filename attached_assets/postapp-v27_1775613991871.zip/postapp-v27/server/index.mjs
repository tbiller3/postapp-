import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { appleFetch, createAppleJwt } from './appleClient.mjs';

const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/apple/health', async (_req, res) => {
  try {
    createAppleJwt();
    res.json({ ok: true, configured: true });
  } catch (error) {
    res.status(500).json({ ok: false, configured: false, error: error.message });
  }
});

app.get('/api/apple/apps', async (_req, res) => {
  try {
    const data = await appleFetch('/apps?limit=50');
    res.json(data);
  } catch (error) {
    res.status(error.status || 500).json({ error: error.message, details: error.payload || null });
  }
});

app.get('/api/apple/apps/:id', async (req, res) => {
  try {
    const data = await appleFetch(`/apps/${req.params.id}`);
    res.json(data);
  } catch (error) {
    res.status(error.status || 500).json({ error: error.message, details: error.payload || null });
  }
});

app.get('/api/apple/apps/:id/appStoreVersions', async (req, res) => {
  try {
    const data = await appleFetch(`/apps/${req.params.id}/appStoreVersions?limit=50&include=appStoreVersionLocalizations`);
    res.json(data);
  } catch (error) {
    res.status(error.status || 500).json({ error: error.message, details: error.payload || null });
  }
});

const port = process.env.PORT || 3001;
app.listen(port, () => {
  console.log(`POSTAPP V27 server listening on http://localhost:${port}`);
});
