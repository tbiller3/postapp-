import type { AppleApp, AppleAppStoreVersion } from '../types/apple';

const API_BASE = import.meta.env.VITE_POSTAPP_SERVER_URL || 'http://localhost:3001';

async function request<T>(path: string): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`);
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data?.error || 'Request failed');
  }
  return data as T;
}

export async function getAppleHealth() {
  return request<{ ok: boolean; configured: boolean; error?: string }>('/api/apple/health');
}

export async function getAppleApps() {
  return request<{ data: AppleApp[] }>('/api/apple/apps');
}

export async function getAppleApp(id: string) {
  return request<{ data: AppleApp }>('/api/apple/apps/' + id);
}

export async function getAppleAppStoreVersions(id: string) {
  return request<{ data: AppleAppStoreVersion[] }>('/api/apple/apps/' + id + '/appStoreVersions');
}
