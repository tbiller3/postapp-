import { useEffect } from 'react';
import { useAppleConnectStore } from '../state/appleConnectStore';

export default function AppleConnectPanel() {
  const {
    health,
    apps,
    selectedApp,
    versions,
    isLoading,
    error,
    loadHealth,
    loadApps,
    selectApp
  } = useAppleConnectStore();

  useEffect(() => {
    void loadHealth();
  }, [loadHealth]);

  return (
    <div className="v27-panel">
      <div className="v27-head">
        <div>
          <h2>App Store Connect Sync</h2>
          <p>Connect POSTAPP to your live Apple app records and versions.</p>
        </div>
        <div className={`v27-health ${health?.configured ? 'ok' : 'bad'}`}>
          {health?.configured ? 'Configured' : 'Not Configured'}
        </div>
      </div>

      <div className="v27-actions">
        <button onClick={() => void loadHealth()}>Check Apple config</button>
        <button onClick={() => void loadApps()}>Load apps</button>
      </div>

      {error && <div className="v27-error">{error}</div>}
      {isLoading && <div className="v27-loading">Loading…</div>}

      <div className="v27-grid">
        <section className="v27-card">
          <h3>Your apps</h3>
          {!apps.length ? (
            <p>No apps loaded yet.</p>
          ) : (
            <div className="v27-list">
              {apps.map((app) => (
                <button
                  key={app.id}
                  className={`v27-app-btn ${selectedApp?.id === app.id ? 'active' : ''}`}
                  onClick={() => void selectApp(app.id)}
                >
                  <strong>{app.attributes.name}</strong>
                  <span>{app.attributes.bundleId}</span>
                </button>
              ))}
            </div>
          )}
        </section>

        <section className="v27-card">
          <h3>Selected app</h3>
          {!selectedApp ? (
            <p>Select an app to view live metadata.</p>
          ) : (
            <div className="v27-details">
              <div><span>Name</span><strong>{selectedApp.attributes.name}</strong></div>
              <div><span>Bundle ID</span><strong>{selectedApp.attributes.bundleId}</strong></div>
              <div><span>SKU</span><strong>{selectedApp.attributes.sku}</strong></div>
              <div><span>Primary locale</span><strong>{selectedApp.attributes.primaryLocale || '—'}</strong></div>
            </div>
          )}
        </section>
      </div>

      <section className="v27-card" style={{ marginTop: 16 }}>
        <h3>App Store versions</h3>
        {!versions.length ? (
          <p>No versions loaded yet.</p>
        ) : (
          <div className="v27-version-list">
            {versions.map((version) => (
              <div key={version.id} className="v27-version-row">
                <strong>{version.attributes.versionString || 'Unknown version'}</strong>
                <span>{version.attributes.appStoreState || 'Unknown state'}</span>
                <span>{version.attributes.platform || '—'}</span>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
