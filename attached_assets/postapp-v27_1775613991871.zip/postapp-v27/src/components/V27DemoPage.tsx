import AppleConnectPanel from './AppleConnectPanel';

export default function V27DemoPage() {
  return <AppleConnectPanel />;
}
