import { create } from 'zustand';
import { getAppleApp, getAppleApps, getAppleAppStoreVersions, getAppleHealth } from '../api/appleApi';
import type { AppleApp, AppleAppStoreVersion } from '../types/apple';

type State = {
  health: { ok: boolean; configured: boolean; error?: string } | null;
  apps: AppleApp[];
  selectedApp: AppleApp | null;
  versions: AppleAppStoreVersion[];
  isLoading: boolean;
  error: string | null;
  loadHealth: () => Promise<void>;
  loadApps: () => Promise<void>;
  selectApp: (id: string) => Promise<void>;
};

export const useAppleConnectStore = create<State>((set) => ({
  health: null,
  apps: [],
  selectedApp: null,
  versions: [],
  isLoading: false,
  error: null,

  loadHealth: async () => {
    set({ isLoading: true, error: null });
    try {
      const health = await getAppleHealth();
      set({ health, isLoading: false });
    } catch (error) {
      set({ error: error instanceof Error ? error.message : 'Unknown error', isLoading: false });
    }
  },

  loadApps: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await getAppleApps();
      set({ apps: response.data, isLoading: false });
    } catch (error) {
      set({ error: error instanceof Error ? error.message : 'Unknown error', isLoading: false });
    }
  },

  selectApp: async (id: string) => {
    set({ isLoading: true, error: null });
    try {
      const [appRes, versionRes] = await Promise.all([
        getAppleApp(id),
        getAppleAppStoreVersions(id)
      ]);
      set({
        selectedApp: appRes.data,
        versions: versionRes.data,
        isLoading: false
      });
    } catch (error) {
      set({ error: error instanceof Error ? error.message : 'Unknown error', isLoading: false });
    }
  }
}));
