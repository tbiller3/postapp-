export type AppleApp = {
  id: string;
  type: 'apps';
  attributes: {
    name: string;
    bundleId: string;
    sku: string;
    primaryLocale?: string;
  };
};

export type AppleAppStoreVersion = {
  id: string;
  type: 'appStoreVersions';
  attributes: {
    versionString?: string;
    platform?: string;
    appStoreState?: string;
    copyright?: string;
    createdDate?: string;
  };
};
