
const express = require("express");
const app = express();

app.get("/", (req,res)=>{
  res.send("POSTAPP V31–V45 PACKAGE RUNNING");
});

app.listen(3000, ()=>{
  console.log("Server running on port 3000");
});
